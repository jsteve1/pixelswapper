// Background script for Parkour Pixel
chrome.runtime.onInstalled.addListener(() => {
  console.log('Parkour Pixel extension installed');
}); 